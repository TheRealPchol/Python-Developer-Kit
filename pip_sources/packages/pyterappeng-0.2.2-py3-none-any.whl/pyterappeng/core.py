import os
import sys

_lines_count = 0
tersizeX = 0
tersizeY = 0

def _update_terminal_size():
    global tersizeX, tersizeY
    try:
        size = os.get_terminal_size()
        tersizeX = size.columns
        tersizeY = size.lines
    except OSError:
        tersizeX = 80
        tersizeY = 24

_update_terminal_size()

def create_lines(lines_count: int):
    global _lines_count
    _lines_count = lines_count
    current_module = sys.modules[__name__]
    for i in range(1, lines_count + 1):
        setattr(current_module, f"line{i}", "")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def update(clear: bool = True):
    if clear:
        clear_screen()
    current_module = sys.modules[__name__]
    for i in range(1, _lines_count + 1):
        line_content = getattr(current_module, f"line{i}", "")
        print(line_content)

def get_key() -> str:
    if os.name == 'nt':
        import msvcrt
        char = msvcrt.getch()
        try:
            return char.decode('utf-8')
        except UnicodeDecodeError:
            return str(char)
    else:
        import tty
        import termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            char = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        if ord(char) == 3:
            sys.exit()
        return char

class Colors:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BOLD = "\033[1m"
